﻿namespace WpfApp1
{

    class TvProgramm
    {
        public TvProgramm(string Date, string Program)
        {
            this.Date = Date;
            this.Program = Program;
        }
        public string Date { get; set; }
        public string Program { get; set; }
    }
}

